// --------------------------------------------------------------------
//	BDF2BIN (����t�H���g��p)
// --------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

static unsigned char font[ 7646 * 8 ] = { 0 };
static unsigned int fill_font[ 7646 ] = { 0 };

typedef struct{
	int fbx_w;
	int fbx_h;
	int fbx_x;
	int fbx_y;
	int eocoding;
	int x;
	int y;
	int width;
	int address;
	unsigned char data[ 8 ];
} FONT_DATA_T;

typedef struct {
	unsigned int encoding;
	unsigned int renew_encoding;
} REPLACE_T;

static REPLACE_T fource_over_write[] = {
	{ 0xFFE3, 0x00AF },		//	�P
	{ 0x2016, 0x2225 },		//	�a
	{ 0xFFE0, 0x00A2 },		//	��
	{ 0xFFE1, 0x00A3 },		//	��
	{ 0xFFE2, 0x00AC },		//	��
	{ 0x00A5, 0x005C },		//	��(���p)
	{ 0x00A6, 0x007C },		//	|
};

// --------------------------------------------------------------------
static int is_force_over_write( int code ){
	int i;

	for( i = 0; i < sizeof( fource_over_write ) / sizeof( fource_over_write[ 0 ] ); i++ ){
		if( code == fource_over_write[ i ].encoding ){
			return fource_over_write[ i ].renew_encoding;
		}
	}
	return 0;
}

// --------------------------------------------------------------------
static void usage( const char *p_name ){

	printf( "Usage> %s <in.bdf> <out.bin>\n", p_name );
}

// --------------------------------------------------------------------
static void get_one_font( FILE *p_in, FONT_DATA_T *p_data ){
	char s_buffer[ 256 ];
	wchar_t s_wbuffer[ 3 ];
	int dummy, a, b, w, h;
	size_t r;
	int fource_over_write;

	memset( p_data->data, 0, sizeof( p_data->data ) );
	p_data->eocoding = 0;
	p_data->x = 0;
	p_data->y = 0;
	p_data->width = 0;
	p_data->address = 0;
	for( ;; ){
		fgets( s_buffer, sizeof( s_buffer ), p_in );
		if( feof( p_in ) ){
			break;
		}
		if( strncmp( s_buffer, "ENCODING", 8 ) == 0 ){
			p_data->eocoding = atoi( s_buffer + 8 );
			if( p_data->eocoding == '2' ){
				p_data->eocoding = p_data->eocoding;
			}
		}
		else if( strncmp( s_buffer, "DWIDTH", 6 ) == 0 ){
			p_data->width = atoi( s_buffer + 6 );
		}
		else if( strncmp( s_buffer, "BBX", 3 ) == 0 ){
			sscanf( s_buffer + 3, "%d %d %d %d", &w, &h, &( p_data->x ), &( p_data->y ) );
			p_data->width = atoi( s_buffer + 3 );
			p_data->y = ( 8 - h ) - p_data->y + p_data->fbx_y;
		}
		else if( strncmp( s_buffer, "BITMAP", 6 ) == 0 ){
			break;
		}
	}

	for( ;; ){
		fgets( s_buffer, sizeof( s_buffer ), p_in );
		if( feof( p_in ) ){
			break;
		}
		if( strncmp( s_buffer, "ENDCHAR", 7 ) == 0 ){
			break;
		}
		if( 0 <= p_data->y && p_data->y < 8 ){
			sscanf( s_buffer, "%x", &dummy );
			p_data->data[ p_data->y ] = dummy >> p_data->x;
		}
		p_data->y++;
	}

	if( is_force_over_write( p_data->eocoding ) ){
		p_data->eocoding = is_force_over_write( p_data->eocoding );
		fource_over_write = 1;
	}
	else{
		fource_over_write = 0;
	}

	s_wbuffer[ 0 ] = (wchar_t)p_data->eocoding;
	s_wbuffer[ 1 ] = 0;
	r = wcstombs( s_buffer, s_wbuffer, sizeof( s_buffer ) );
	if( (unsigned char)s_buffer[ 0 ] < 32 ){
		//	��������
		p_data->address = -1;
	}
	else if( (unsigned char)s_buffer[ 0 ] < 128 ){
		//	ASCII���� ( 32�`127 --> 0�`95 )
		p_data->address = (unsigned char)s_buffer[ 0 ] - 32;
	}
	else if( (unsigned char)s_buffer[ 0 ] <= 132 ){		//	0x84
		//	��1��`��8�� ( 159�`926 ) : 1��� = 96����
		a = (unsigned char)s_buffer[ 0 ] - 0x81;		//	0x81�`0x84
		b = (unsigned char)s_buffer[ 1 ] - 0x40;
		p_data->address = ( 159 + ( a * 192 + b ) );
	}
	else if( (unsigned char)s_buffer[ 0 ] < 136 ){			//	0x88
		//	��������
		p_data->address = -1;
	}
	else if( (unsigned char)s_buffer[ 0 ] <= 159 ){			//	0x9F
		//	��16��`��62�� ( 927�`5534 ) : 1��� = 96����
		a = (unsigned char)s_buffer[ 0 ] - 0x88;	//	0x88�`0x9F
		b = (unsigned char)s_buffer[ 1 ] - 0x40;
		p_data->address = ( 927 + ( a * 192 + b ) );
	}
	else if( (unsigned char)s_buffer[ 0 ] < 161 ){			//	0xA1
		//	��������
		p_data->address = -1;
	}
	else if( (unsigned char)s_buffer[ 0 ] < 224 ){			//	0xE0
		//	�J�i���� ( 161�`223 --> 96�`158 )
		p_data->address = (unsigned char)s_buffer[ 0 ] - 161 + 96;
	}
	else if( (unsigned char)s_buffer[ 0 ] <= 234 ){
		//	��63��`��84�� ( 5535�`7646 ) : 1��� = 96����
		a = (unsigned char)s_buffer[ 0 ] - 0xE0;			//	0xE0�`0xEA
		b = (unsigned char)s_buffer[ 1 ] - 0x40;
		p_data->address = ( 5535 + ( a * 192 + b ) );
	}
	else {
		//	��������
		p_data->address = -1;
	}
	if( fource_over_write && p_data->address >= 0 ){
		fill_font[ p_data->address ] = 0;
	}
}

// --------------------------------------------------------------------
int main( int argc, char *argv[] ){
	FILE *p_in, *p_out;
	char s_buffer[ 256 ];
	FONT_DATA_T data;
	int w, h, x, y;

	printf( "BDF2BIN for MISAKI-FONT\n" );
	if( argc < 3 ){
		usage( argv[ 0 ] );
		return 0;
	}

	p_in = fopen( argv[ 1 ], "r" );
	if( p_in == NULL ){
		printf( "ERROR: Cannot open the '%s'.\n", argv[ 1 ] );
		return 0;
	}

	setlocale( LC_ALL, "Japanese" );

	w = h = 8;
	x = y = 0;
	for( ;; ){
		fgets( s_buffer, sizeof( s_buffer ), p_in );
		if( feof( p_in ) ){
			break;
		}
		if( strncmp( s_buffer, "FONTBOUNDINGBOX", 15 ) == 0 ){
			sscanf( s_buffer + 15, "%d %d %d %d", &w, &h, &x, &y );
			break;
		}
	}
	data.fbx_w = w;
	data.fbx_h = h;
	data.fbx_x = x;
	data.fbx_y = y;

	for( ;; ){
		fgets( s_buffer, sizeof( s_buffer ), p_in );
		if( feof( p_in ) ){
			break;
		}
		if( strncmp( s_buffer, "STARTCHAR", 9 ) == 0 ){
			get_one_font( p_in, &data );
			if( data.address != -1 ) {
				if( fill_font[ data.address ] ){
					printf( "Overmap charcter code %d.\n", data.address );
				}
				else{
					memcpy( &font[ data.address * 8 ], data.data, 8 );
					fill_font[ data.address ] = 1;
				}
/*
				if( is_force_over_write( data.eocoding ) ){	//	debug
					printf( "=============== encode 0x%08X --> address:%d\n", data.eocoding, data.address );
					for( int i = 0; i < 8; i++ ){
						for( int j = 0; j < 8; j++ ){
							printf( "%c", "01"[ ( data.data[ i ] & ( 0x80 >> j ) ) != 0 ] );
						}
						printf( "\n" );
					}
				}
*/
			}
		}
	}
	fclose( p_in );

	p_out = fopen( argv[ 2 ], "wb" );
	fwrite( font, sizeof( font ), 1, p_out );
	fclose( p_out );
	return 0;
}