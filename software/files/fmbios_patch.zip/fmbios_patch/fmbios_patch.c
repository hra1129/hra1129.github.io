// --------------------------------------------------------------------
//	FM-BIOS patch
//
//	1chipMSX �� FM-BIOS �Ƀp�b�`�𓖂Ă� FMPAC �� BIOS �̃t��������B
//	�������ACALL FMPAC �͎g���Ȃ��B�V�O�l�`���� "ARPLOPLL" ���� "PAC2OPLL"
//	�ɕύX���āAROM �̌㔼�Ƀp�f�B���O��ǉ�����̂݁B
// ====================================================================
//	2020/11/12	t.hara
// --------------------------------------------------------------------

#include <stdio.h>
#include <string.h>

static unsigned char s_buffer[ 65536 ];

static unsigned char s_signature[] = { 'A', 'B',
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 'P', 'A', 'C', '2', 'O', 'P', 'L', 'L' };

// --------------------------------------------------------------------
int main( int argc, char *argv[] ) {
	FILE *p_in, *p_out;

	memset( s_buffer, 0xFF, sizeof(s_buffer) );

	p_in = fopen( "ocm_msx2_opll.rom", "rb" );
	if( p_in == NULL ) {
		printf( "ERROR: Cannot open 'ocm_msx2_opll.rom'\n" );
		return 1;
	}
	fread( s_buffer, 16384, 1, p_in );
	fclose( p_in );

	memcpy( s_buffer + 0x0018, "PAC2OPLL", 8 );
	memcpy( s_buffer + 0x4000, s_signature, sizeof(s_signature) );
	memcpy( s_buffer + 0x8000, s_signature, sizeof(s_signature) );
	memcpy( s_buffer + 0xC000, s_signature, sizeof(s_signature) );

	p_out = fopen( "FMPCCMFC.BIN", "wb" );
	if( p_out == NULL ) {
		printf( "ERROR: Cannot create 'FMPCCMFC.BIN'\n" );
		return 1;
	}
	fwrite( s_buffer, sizeof(s_buffer), 1, p_out );
	fclose( p_out );
	printf( "Completed!!!\n" );
	return 0;
}
