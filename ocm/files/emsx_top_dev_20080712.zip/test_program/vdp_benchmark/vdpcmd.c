/* --------------------------------------------------------- */
/*	VDP COMMAND TEST FOR V9958								 */
/* ========================================================= */
/*	2008/05/02	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <msx/msx.h>

static FCB file;
static char buffer[128];

#define TEST_TIMES 100

/* --------------------------------------------------------- */
static void set_name( FCB *p_fcb, const char *p_name ) {
	int i, j;

	memset( p_fcb, 0, sizeof(FCB) );
	for( i = 0; i < 11; i++ ) {
		p_fcb->name[i] = ' ';
	}
	for( i = 0; (i < 8) && (p_name[i] != 0) && (p_name[i] != '.'); i++ ) {
		p_fcb->name[i] = toupper( p_name[i] );
	}
	if( p_name[i] == '.' ) {
		i++;
		for( j = 0; (j < 3) && (p_name[i + j] != 0) && (p_name[i + j] != '.'); j++ ) {
			p_fcb->ext[j] = toupper( p_name[i + j] );
		}
	}
}

/* --------------------------------------------------------- */
static void vram_load( const char *p_name ) {
	int x, y, adr;

	set_name( &file, p_name );
	if( fcb_open( &file ) != FCB_SUCCESS ) return;
	/* skip file header */
	fcb_read( &file, buffer, 7 );
	/* load bitmap and palette */
	adr = 0;
	/* 30368bytes = 237line * 128bytes (bitmap) + 32bytes (palette) */
	for( y = 0; y < 237; y++ ) {
		fcb_read( &file, buffer, 128 );
		disable_intr();
		vpoke_first( adr );
		for( x = 0; x < 128; x++ ) {
			vpoke_next( buffer[x] );
		}
		enable_intr();
		adr += 128;
	}
	fcb_read( &file, buffer, 32 );
	fcb_close( &file );
	/* palette initialize */
	disable_intr();
	vdp_write( 16, 0 );
	for( x = 0; x < 32; x++ ) {
		outport( 0x9A, buffer[x] );
	}
	enable_intr();
}

/* --------------------------------------------------------- */
static void start_and_wait_vdp_command( int command ) {

	outport( 0x9B, command );	/* R#46: CMD */

	vdp_write_ni( 15, 2 );		/* VDP status register S#2 read */
	while( inport(0x99) & 1 );	/* wait complete */
	vdp_write_ni( 15, 0 );
}

/* --------------------------------------------------------- */
static void copy_page0_to_page2( void ) {

	disable_intr();
	vdp_write_ni( 17, 32 );		/* VDP register write (auto increment mode) from R#32 */

	/* copy (0,0)-step(256,256),0 to (0,0),2 */
	outport( 0x9B, 0 );			/* R#32: SX */
	outport( 0x9B, 0 );			/* R#33: SX */
	outport( 0x9B, 0 );			/* R#34: SY */
	outport( 0x9B, 0 );			/* R#35: SY */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 2 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: NX */
	outport( 0x9B, 1 );			/* R#41: NX */
	outport( 0x9B, 0 );			/* R#42: NY */
	outport( 0x9B, 1 );			/* R#43: NY */
	outport( 0x9B, 0 );			/* R#44: -- */
	outport( 0x9B, 0 );			/* R#45: ARG */
	/* R#46: CMD = HMMM */
	start_and_wait_vdp_command( 0xD0 );
	enable_intr();
}

/* --------------------------------------------------------- */
static void copy_page2_to_page0( void ) {

	disable_intr();
	vdp_write_ni( 17, 32 );		/* VDP register write (auto increment mode) from R#32 */

	/* copy (0,0)-step(256,256),2 to (0,0),0 */
	outport( 0x9B, 0 );			/* R#32: SX */
	outport( 0x9B, 0 );			/* R#33: SX */
	outport( 0x9B, 0 );			/* R#34: SY */
	outport( 0x9B, 2 );			/* R#35: SY */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: NX */
	outport( 0x9B, 1 );			/* R#41: NX */
	outport( 0x9B, 0 );			/* R#42: NY */
	outport( 0x9B, 1 );			/* R#43: NY */
	outport( 0x9B, 0 );			/* R#44: -- */
	outport( 0x9B, 0 );			/* R#45: ARG */
	/* R#46: CMD = HMMM */
	start_and_wait_vdp_command( 0xD0 );
	enable_intr();
}

/* --------------------------------------------------------- */
static int set_vdp_command_hmmm( void ) {

	vdp_write_ni( 17, 32 );		/* VDP register write (auto increment mode) from R#32 */

	/* copy (2,0)-step(254,256),0 to (0,0),0 */
	outport( 0x9B, 2 );			/* R#32: SX */
	outport( 0x9B, 0 );			/* R#33: SX */
	outport( 0x9B, 0 );			/* R#34: SY */
	outport( 0x9B, 0 );			/* R#35: SY */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 254 );		/* R#40: NX */
	outport( 0x9B, 0 );			/* R#41: NX */
	outport( 0x9B, 0 );			/* R#42: NY */
	outport( 0x9B, 1 );			/* R#43: NY */
	outport( 0x9B, 0 );			/* R#44: -- */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0xD0;				/* R#46: CMD = HMMM */
}

/* --------------------------------------------------------- */
static int set_vdp_command_ymmm( void ) {

	vdp_write_ni( 17, 34 );		/* VDP register write (auto increment mode) from R#34 */

	/* copy (0,1)-step(256,256),0 to (0,0),0 */
	outport( 0x9B, 1 );			/* R#34: SY */
	outport( 0x9B, 0 );			/* R#35: SY */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: -- */
	outport( 0x9B, 0 );			/* R#41: -- */
	outport( 0x9B, 255 );		/* R#42: NY */
	outport( 0x9B, 0 );			/* R#43: NY */
	outport( 0x9B, 0 );			/* R#44: -- */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0xE0;				/* R#46: CMD = YMMM */
}

/* --------------------------------------------------------- */
static int set_vdp_command_hmmv( void ) {

	vdp_write_ni( 17, 36 );		/* VDP register write (auto increment mode) from R#36 */

	/* line (0,0)-step(256,256), &H80,BF */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: NX */
	outport( 0x9B, 1 );			/* R#41: NX */
	outport( 0x9B, 212 );		/* R#42: NY */
	outport( 0x9B, 0 );			/* R#43: NY */
	outport( 0x9B, 0x80 );		/* R#44: CLR */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0xC0;				/* R#46: CMD = HMMV */
}

/* --------------------------------------------------------- */
static int set_vdp_command_lmmm( void ) {

	vdp_write_ni( 17, 32 );		/* VDP register write (auto increment mode) from R#32 */

	/* copy (2,0)-step(254,64),0 to (0,0),0 */
	outport( 0x9B, 2 );			/* R#32: SX */
	outport( 0x9B, 0 );			/* R#33: SX */
	outport( 0x9B, 0 );			/* R#34: SY */
	outport( 0x9B, 0 );			/* R#35: SY */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 254 );		/* R#40: NX */
	outport( 0x9B, 0 );			/* R#41: NX */
	outport( 0x9B, 64 );		/* R#42: NY */
	outport( 0x9B, 0 );			/* R#43: NY */
	outport( 0x9B, 0 );			/* R#44: -- */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0x90;				/* R#46: CMD = LMMM, IMP */
}

/* --------------------------------------------------------- */
static int set_vdp_command_lmmv( void ) {

	vdp_write_ni( 17, 36 );		/* VDP register write (auto increment mode) from R#36 */

	/* line (0,0)-step(256,128), 8,BF */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: NX */
	outport( 0x9B, 1 );			/* R#41: NX */
	outport( 0x9B, 128 );		/* R#42: NY */
	outport( 0x9B, 0 );			/* R#43: NY */
	outport( 0x9B, 8 );			/* R#44: CLR */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0x80;				/* R#46: CMD = LMMV, IMP */
}

/* --------------------------------------------------------- */
static int set_vdp_command_line( void ) {

	vdp_write_ni( 17, 36 );		/* VDP register write (auto increment mode) from R#36 */

	/* line (0,0)-step(256,128), 8,BF */
	outport( 0x9B, 0 );			/* R#36: DX */
	outport( 0x9B, 0 );			/* R#37: DX */
	outport( 0x9B, 0 );			/* R#38: DY */
	outport( 0x9B, 0 );			/* R#39: DY */
	outport( 0x9B, 0 );			/* R#40: NX */
	outport( 0x9B, 1 );			/* R#41: NX */
	outport( 0x9B, 0 );			/* R#42: NY */
	outport( 0x9B, 1 );			/* R#43: NY */
	outport( 0x9B, 12 );		/* R#44: CLR */
	outport( 0x9B, 1 );			/* R#45: ARG */
	return 0x73;				/* R#46: CMD = LINE, XOR */
}

/* --------------------------------------------------------- */
static int set_vdp_command_srch( void ) {

	vdp_write_ni( 17, 32 );		/* VDP register write (auto increment mode) from R#32 */
	outport( 0x9B, 0 );			/* R#32: SX */
	outport( 0x9B, 0 );			/* R#33: SX */
	outport( 0x9B, 0 );			/* R#34: SY */
	outport( 0x9B, 0 );			/* R#35: SY */

	vdp_write_ni( 17, 44 );		/* VDP register write (auto increment mode) from R#44 */
	outport( 0x9B, 0 );			/* R#44: CLR */
	outport( 0x9B, 0 );			/* R#45: ARG */
	return 0x60;				/* R#46: CMD = SRCH */
}

/* --------------------------------------------------------- */
#define TEST_OF_COMMAND	(sizeof(p_set_vdp_command)/sizeof(p_set_vdp_command[0]))

/* --------------------------------------------------------- */
static int (*p_set_vdp_command[])( void ) = {
	set_vdp_command_ymmm,
	set_vdp_command_hmmm,
	set_vdp_command_hmmv,
	set_vdp_command_lmmm,
	set_vdp_command_lmmv,
	set_vdp_command_line,
	set_vdp_command_srch,
};

static const char *s_command[ TEST_OF_COMMAND ] = {
	"YMMM",
	"HMMM",
	"HMMV",
	"LMMM",
	"LMMV",
	"LINE",
	"SRCH",
};

/* --------------------------------------------------------- */
int main( void ) {
	int start_time, end_time;
	int proc_time[TEST_OF_COMMAND], diff, i, j, command;
	long total_proc_time;

	screen( 5 );
	vdp_write( 7, 0 );					/* back ground color = 0 */
	vram_load( "MIYAZAKI.SC5" );
	copy_page0_to_page2();

	for( j = 0; j < TEST_OF_COMMAND; j++ ) {
		proc_time[j] = 0;
		for( i = 0; i < TEST_TIMES; i++ ) {
			disable_intr();
			command = (p_set_vdp_command[j])();
			start_time = inport( 0xE7 );
			start_and_wait_vdp_command( command );
			end_time = inport( 0xE7 );
			enable_intr();
			diff = (end_time & 255) - (start_time & 255);
			if( diff < 0 ) {
				diff += 256;
			}
			proc_time[j] += diff;
		}
		copy_page2_to_page0();
	}

	screen( 0 );
	total_proc_time = 0;
	for( j = 0; j < TEST_OF_COMMAND; j++ ) {
		printf( "%s = %d\n", s_command[j], proc_time[j] );
		total_proc_time += proc_time[j];
	}
	printf( "TOTAL PROC TIME = %ld\n", total_proc_time );
	return 0;
}
