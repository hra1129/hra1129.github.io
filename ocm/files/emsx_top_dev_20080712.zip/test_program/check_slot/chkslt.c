/* --------------------------------------------------------- */
/*	SLOT0 CHECK PROGRAM FOR ONE CHIP MSX					 */
/* ========================================================= */
/*	2008/04/05	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <msx/msx.h>

#define DUMP_SIZE	16

int back_sp;
static char slot_data[DUMP_SIZE];

/* --------------------------------------------------------- */
static char change_slot_for_page1( char slot ) {
	char prev_slot;

	/* change slot of page1 */
	disable_intr();
	prev_slot = inport( 0xA8 );
	outport( 0xA8, (prev_slot & 0xF3) | (slot << 2) );
	enable_intr();
	return (prev_slot >> 2) & 3;
}

/* --------------------------------------------------------- */
static char change_expslot_for_page1( char slot, char expslot ) {
	char prev_slot, prev_expslot;

	disable_intr();
	/* change slot of page3 for expand slot register */
	prev_slot = inport( 0xA8 );
	outport( 0xA8, (prev_slot & 0x3F) | (slot << 6) );
	/* change expand slot of page1 */
	prev_expslot = ~peek( 0xFFFF );
	poke( 0xFFFF, (prev_expslot & 0xF3) | (expslot << 2) );
	/* restore slot of page3 */
	outport( 0xA8, prev_slot );
	enable_intr();
	return (prev_expslot >> 2) & 3;
}

/* --------------------------------------------------------- */
static void slot_dump( char expslot ) {
	char prev_slot, prev_expslot;
	int i;

	prev_slot		= change_slot_for_page1(	0 );
	prev_expslot	= change_expslot_for_page1(	0, expslot );
	memcpy( slot_data, 0x4000, sizeof(slot_data) );
	change_expslot_for_page1(	0, prev_expslot );
	change_slot_for_page1(		prev_slot );

	printf( "SLOT0-%d:", expslot );
	for( i = 0; i < sizeof(slot_data); i++ ) {
		if( (i & 7) == 0 ) printf( "\n" );
		printf( "%02X ", (int)(unsigned char)slot_data[i] );
	}
	printf( "\n" );
}

/* --------------------------------------------------------- */
int main( void ) {

	_asm;
	di;
	ld		(_back_sp), sp;
	ld		hl, #0xBFFF;			/* page2 */
	ld		sp, hl;
	ei;
	_endasm;

	slot_dump(0);
	slot_dump(1);
	slot_dump(2);
	slot_dump(3);

	_asm;
	di;
	ld		sp, (_back_sp);
	ei;
	_endasm;

	return 0;
}
