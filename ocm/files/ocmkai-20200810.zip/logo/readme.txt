1chipMSX-kai v1.0 by HRA! and KdL (2020.01.15)
==============================================

- Replace 'knocmkai.rom' to 'kn2plfix.rom' in the 'make\roms\' path of OCM-SDBIOS Pack
  in order to use the 1chipMSX-kai logo as the default MSX2+ logo.

Note:
the final logo does not include the pixels of the antialiases because
there is not enough space to make it enter the 'msxkanji.rom' file.


______
Enjoy!
