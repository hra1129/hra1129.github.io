/* --------------------------------------------------------- */
/*	H-SCROLL TEST FOR V9958									 */
/* ========================================================= */
/*	2008/04/06	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <msx/msx.h>

static FCB file;
static char buffer[128];

/* --------------------------------------------------------- */
static void wait( int j ) {
	volatile int i;

	for( i = 0; i < j; i++ ) {
	}
}

/* --------------------------------------------------------- */
static void set_name( FCB *p_fcb, const char *p_name ) {
	int i, j;

	memset( p_fcb, 0, sizeof(FCB) );
	for( i = 0; i < 11; i++ ) {
		p_fcb->name[i] = ' ';
	}
	for( i = 0; (i < 8) && (p_name[i] != 0) && (p_name[i] != '.'); i++ ) {
		p_fcb->name[i] = toupper( p_name[i] );
	}
	if( p_name[i] == '.' ) {
		i++;
		for( j = 0; (j < 3) && (p_name[i + j] != 0) && (p_name[i + j] != '.'); j++ ) {
			p_fcb->ext[j] = toupper( p_name[i + j] );
		}
	}
}

/* --------------------------------------------------------- */
static void vram_load( const char *p_name ) {
	int x, y, adr;

	set_name( &file, p_name );
	if( fcb_open( &file ) != FCB_SUCCESS ) return;
	/* skip file header */
	fcb_read( &file, buffer, 7 );
	/* load bitmap and palette */
	adr = 0;
	/* 30368bytes = 237line * 128bytes (bitmap) + 32bytes (palette) */
	for( y = 0; y < 237; y++ ) {
		fcb_read( &file, buffer, 128 );
		disable_intr();
		vpoke_first( adr );
		for( x = 0; x < 128; x++ ) {
			vpoke_next( buffer[x] );
		}
		enable_intr();
		adr += 128;
	}
	fcb_read( &file, buffer, 32 );
	fcb_close( &file );
	/* palette initialize */
	disable_intr();
	vdp_write( 16, 0 );
	for( x = 0; x < 32; x++ ) {
		outport( 0x9A, buffer[x] );
	}
	enable_intr();
}

/* --------------------------------------------------------- */
int main( void ) {
	int x, s;

	screen( 5 );
	vram_load( "OCM.SC5" );
	for( s = 0; s < 5; s++ ) {
		for( x = 0; x < 256; x++ ) {
			vdp_write( 26, x >> 3 );
			vdp_write( 27, (7 - x) & 7 );
			wait( 1000 );
		}
	}
	vdp_write( 26, 0 );
	vdp_write( 27, 0 );
	screen( 0 );
	return 0;
}
