/* --------------------------------------------------------- */
/*	YJK TEST FOR V9958										 */
/* ========================================================= */
/*	2008/04/09	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <msx/msx.h>

static FCB file;
static char buffer[256];

static const unsigned char ball_pattern[] = {
	0x3C, /* 00111100 */
	0x7E, /* 01111110 */
	0xFF, /* 11111111 */
	0xFF, /* 11111111 */
	0xFF, /* 11111111 */
	0xFF, /* 11111111 */
	0x7E, /* 01111110 */
	0x3C  /* 00111100 */
};

static int sp_x[32];
static int sp_y[32];
static int vx[32];
static int vy[32];

/* --------------------------------------------------------- */
static void wait( int j ) {
	volatile int i;

	for( i = 0; i < j; i++ ) {
	}
}

/* --------------------------------------------------------- */
static void set_name( FCB *p_fcb, const char *p_name ) {
	int i, j;

	memset( p_fcb, 0, sizeof(FCB) );
	for( i = 0; i < 11; i++ ) {
		p_fcb->name[i] = ' ';
	}
	for( i = 0; (i < 8) && (p_name[i] != 0) && (p_name[i] != '.'); i++ ) {
		p_fcb->name[i] = toupper( p_name[i] );
	}
	if( p_name[i] == '.' ) {
		i++;
		for( j = 0; (j < 3) && (p_name[i + j] != 0) && (p_name[i + j] != '.'); j++ ) {
			p_fcb->ext[j] = toupper( p_name[i + j] );
		}
	}
}

/* --------------------------------------------------------- */
static void vram_load( const char *p_name ) {
	int x, y, adr;

	set_name( &file, p_name );
	if( fcb_open( &file ) != FCB_SUCCESS ) return;
	/* skip file header */
	fcb_read( &file, buffer, 7 );
	/* load bitmap */
	adr = 0;
	/* 54272bytes = 212line * 256bytes */
	for( y = 0; y < 212; y++ ) {
		fcb_read( &file, buffer, 256 );
		disable_intr();
		vpoke_first( adr );
		for( x = 0; x < 256; x++ ) {
			vpoke_next( buffer[x] );
		}
		enable_intr();
		adr += 256;
	}
	fcb_close( &file );
}

/* --------------------------------------------------------- */
static void set_sprite_color( int sprite_no, int color ) {
	int i;

	disable_intr();
	vpoke_first( 0xF800 + (sprite_no << 4) );
	for( i = 0; i < 8; i++ ) {
		vpoke_next( color );
	}
	enable_intr();
}

/* --------------------------------------------------------- */
static void vsync( void ) {

	/* Vertical synchronize by H-SYNC signal */
	vdp_write( 19, 212 );
	while( (vdp_status( 1 ) & 1) == 0 ) {
	}
}

/* --------------------------------------------------------- */
int main( void ) {
	int x, s, i, m;

	screen( 8 );
	set_sprite_pattern( 0, ball_pattern );

	for( i = 0; i < 32; i++ ) {
		sp_x[i] = (i * 37 + 5) & 255;
		sp_y[i] = (i * 19 + 7) % 212;
		vx[i] = (((i * 23) & 1) << 3) - 4;
		vy[i] = (((i * 57) & 1) << 3) - 4;
		set_sprite_color( i, i & 15 );
		put_sprite( i, sp_x[i], sp_y[i], 0, (i & 7) + 8 );
	}
	vdp_write( 8, 0x20 );		/* TP=1 (enable sprite color 0) */
	m = 0x0A;					/* YJK=1, MSK=1 */
	vram_load( "OCM.SCC" );
	for( s = 0; s < 5; s++ ) {
		for( x = 0; x < 256; x++ ) {
			vsync();
			vdp_write( 26, x >> 3 );
			vdp_write( 27, (7 - x) & 7 );
			vdp_write( 25, m );

			for( i = 0; i < 32; i++ ) {
				put_sprite( i, sp_x[i], sp_y[i], 0, (i & 7) + 8 );

				sp_x[i] = sp_x[i] + vx[i];
				if( sp_x[i] > 255 ) {
					sp_x[i] = 255;
					vx[i] = -vx[i];
				}
				else if( sp_x[i] < 0 ) {
					sp_x[i] = 0;
					vx[i] = -vx[i];
				}

				sp_y[i] = sp_y[i] + vy[i];
				if( sp_y[i] > 211 ) {
					sp_y[i] = 211;
					vy[i] = -vy[i];
				}
				else if( sp_y[i] < 0 ) {
					sp_y[i] = 0;
					vy[i] = -vy[i];
				}
			}
		}
		m = m ^ 0x08;		/* YJK invert */
	}
	vdp_write( 26, 0 );
	vdp_write( 27, 0 );
	screen( 0 );
	return 0;
}
