/* --------------------------------------------------------- */
/*	VDP test												 */
/* ========================================================= */
/*	2008/05/12	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <msx/msx.h>

unsigned char start_time = 0;
unsigned char end_time = 0;
static FCB file;

/* --------------------------------------------------------- */
static void file_printf( FCB *p_fcb, const char *p_format, ... ) {
	va_list param;
	char s_message[128];
	int len;

	va_start( param, p_format );
	vsprintf( s_message, p_format, param );
	va_end( param );

	len = strlen( s_message );
	fcb_write( p_fcb, s_message, len );
}

/* --------------------------------------------------------- */
static void test1( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* set R#15 */
		ld		c, #0x99
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until HR to zero */
wait_HR1:
		in		a, (c)
		and		#0x20
		jr		nz, wait_HR1
		/* wait until HR to non zero */
wait_nHR1:
		in		a, (c)
		and		#0x20
		jr		z, wait_nHR1
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* wait until HR to zero */
wait_HR2:
		in		a, (c)
		and		#0x20
		jr		nz, wait_HR2
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test2( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* set R#15 */
		ld		c, #0x99
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to zero */
test2_1:
		in		a, (c)
		and		#0x40
		jr		nz, test2_1
		/* wait until VR to non zero */
test2_2:
		in		a, (c)
		and		#0x40
		jr		z, test2_2
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* wait until VR to zero */
test2_3:
		in		a, (c)
		and		#0x40
		jr		nz, test2_3
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test3( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #128
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
wait_HS5:
		in		a, (c)
		and		#0x01
		jr		z, wait_HS5
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until HR to non zero */
wait_nHR5:
		in		a, (c)
		and		#0x20
		jr		z, wait_nHR5
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test4( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* backup interrupt vector */
		ld		hl,#0x0038
		ld		de,#test4_backup
		ld		bc,#3
		ldir
		/* update interrupt vector */
		ld		hl,#test4_new
		ld		de,#0x0038
		ld		bc,#3
		ldir
		ld		c,#0xe6
test4_wait_interrupt:
		in		b,(c)
		ei
		jr		test4_wait_interrupt
test4_return:
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* restore interrupt vector */
		ld		hl,#test4_backup
		ld		de,#0x0038
		ld		bc,#3
		ldir
		ei
		jp		test4_skip

test4_backup:
		.ds		3
test4_new:
		jp		test4_intr		/* new interrupt vector. 3bytes (0xC3 XX XX) */
test4_intr:
		in		a,(c)
		pop		hl				/* clear return address */
		jp		test4_return
test4_skip:
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test5( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #220
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test5_1:
		in		a, (c)
		and		#0x01
		jr		z, test5_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test5_2:
		in		a, (c)
		and		#0x40
		jr		z, test5_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test6( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #215
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test6_1:
		in		a, (c)
		and		#0x01
		jr		z, test6_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test6_2:
		in		a, (c)
		and		#0x40
		jr		z, test6_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test7( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #210
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test7_1:
		in		a, (c)
		and		#0x01
		jr		z, test7_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test7_2:
		in		a, (c)
		and		#0x40
		jr		z, test7_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test8( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #210
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test8_1:
		in		a, (c)
		and		#0x01
		jr		z, test8_1
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test8_2:
		in		a, (c)
		and		#0x40
		jr		z, test8_2
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test9( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #128
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test9_1:
		in		a, (c)
		and		#0x01
		jr		z, test9_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
test9_2:
		in		a, (c)
		and		#0x01
		jr		z, test9_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void set_name( FCB *p_fcb, const char *p_name ) {
	int i, j;

	memset( p_fcb, 0, sizeof(FCB) );
	for( i = 0; i < 11; i++ ) {
		p_fcb->name[i] = ' ';
	}
	for( i = 0; (i < 8) && (p_name[i] != 0) && (p_name[i] != '.'); i++ ) {
		p_fcb->name[i] = toupper( p_name[i] );
	}
	if( p_name[i] == '.' ) {
		i++;
		for( j = 0; (j < 3) && (p_name[i + j] != 0) && (p_name[i + j] != '.'); j++ ) {
			p_fcb->ext[j] = toupper( p_name[i + j] );
		}
	}
}

/* --------------------------------------------------------- */
int main( void ) {
	int i;

	memset( &file, 0, sizeof(file) );
	file.drive_no = 0;
	file.current_block = 0;
	set_name( &file, "TEST.TXT" );
	if( fcb_create( &file ) != FCB_SUCCESS ) {
		puts( "Failed: fcb_create()" );
		return 0;
	}

	screen( 1 );
	file_printf( &file, "H BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test1( &file );
	}
	file_printf( &file, "\xD\xAV BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test2( &file );
	}
	file_printf( &file, "\xD\xAH INTERRUPT TO H BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test3( &file );
	}
	file_printf( &file, "\xD\xAINTERRUPT RESPONSE: " );
	for( i = 0; i < 10; i++ ) {
		test4( &file );
	}
	file_printf( &file, "\xD\xALINE220 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test5( &file );
	}
	file_printf( &file, "\xD\xALINE215 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test6( &file );
	}
	file_printf( &file, "\xD\xALINE210 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test7( &file );
	}
	file_printf( &file, "\xD\xALINE210 TO V-BLANK(E6): " );
	for( i = 0; i < 10; i++ ) {
		test8( &file );
	}
	file_printf( &file, "\xD\xAH INTERRUPT TO H INTERRUPT: " );
	for( i = 0; i < 10; i++ ) {
		test9( &file );
	}

	if( fcb_close( &file ) != FCB_SUCCESS ) {
		puts( "Failed: fcb_close()" );
		return 0;
	}
	printf( "Completed.\n" );
	return 0;
}
