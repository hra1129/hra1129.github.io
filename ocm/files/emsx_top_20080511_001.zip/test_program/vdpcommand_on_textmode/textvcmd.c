/* --------------------------------------------------------- */
/*	VDP COMMAND ON TEXT MODE TEST FOR V9958					 */
/* ========================================================= */
/*	2008/04/09	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <msx/msx.h>

/* --------------------------------------------------------- */
int main( void ) {

	screen( 0 );
	vdp_write( 25, 0x40 );	/* enable vdp-command on text mode */
	/* HMMV(FILL BOX) */
	vdp_write( 36, 0 );		/* DX */
	vdp_write( 37, 0 );
	vdp_write( 38, 0 );		/* DY */
	vdp_write( 39, 0 );
	vdp_write( 40, 0 );		/* NX */
	vdp_write( 41, 1 );
	vdp_write( 42, 1 );		/* NY */
	vdp_write( 43, 0 );
	vdp_write( 44, 'A' );	/* CLR */
	vdp_write( 45, 0 );		/* ARG */
	vdp_write( 46, 0xC0 );	/* CMR: HMMV */
	return 0;
}
