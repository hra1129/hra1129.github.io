/* --------------------------------------------------------- */
/*	VDP test												 */
/* ========================================================= */
/*	2008/05/12	t.hara										 */
/* --------------------------------------------------------- */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <msx/msx.h>

unsigned char start_time = 0;
unsigned char end_time = 0;
unsigned char line_data[256];
unsigned char intr_data[256];

static FCB file;

/* --------------------------------------------------------- */
static void file_printf( FCB *p_fcb, const char *p_format, ... ) {
	va_list param;
	static char s_message[128];
	int len;

	va_start( param, p_format );
	vsprintf( s_message, p_format, param );
	va_end( param );

	len = strlen( s_message );
	fcb_write( p_fcb, s_message, len );
}

/* --------------------------------------------------------- */
static void test1( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* set R#15 */
		ld		c, #0x99
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until HR to zero */
wait_HR1:
		in		a, (c)
		and		#0x20
		jr		nz, wait_HR1
		/* wait until HR to non zero */
wait_nHR1:
		in		a, (c)
		and		#0x20
		jr		z, wait_nHR1
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* wait until HR to zero */
wait_HR2:
		in		a, (c)
		and		#0x20
		jr		nz, wait_HR2
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test2( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* set R#15 */
		ld		c, #0x99
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to zero */
test2_1:
		in		a, (c)
		and		#0x40
		jr		nz, test2_1
		/* wait until VR to non zero */
test2_2:
		in		a, (c)
		and		#0x40
		jr		z, test2_2
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* wait until VR to zero */
test2_3:
		in		a, (c)
		and		#0x40
		jr		nz, test2_3
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test3( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #128
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
wait_HS5:
		in		a, (c)
		and		#0x01
		jr		z, wait_HS5
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until HR to non zero */
wait_nHR5:
		in		a, (c)
		and		#0x20
		jr		z, wait_nHR5
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test4( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		/* backup interrupt vector */
		ld		hl,#0x0038
		ld		de,#test4_backup
		ld		bc,#3
		ldir
		/* update interrupt vector */
		ld		hl,#test4_new
		ld		de,#0x0038
		ld		bc,#3
		ldir
		ld		c,#0xe6
test4_wait_interrupt:
		in		b,(c)
		ei
		jr		test4_wait_interrupt
test4_return:
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* restore interrupt vector */
		ld		hl,#test4_backup
		ld		de,#0x0038
		ld		bc,#3
		ldir
		ei
		jp		test4_skip

test4_backup:
		.ds		3
test4_new:
		jp		test4_intr		/* new interrupt vector. 3bytes (0xC3 XX XX) */
test4_intr:
		in		a,(c)
		pop		hl				/* clear return address */
		jp		test4_return
test4_skip:
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test5( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #220
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test5_1:
		in		a, (c)
		and		#0x01
		jr		z, test5_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test5_2:
		in		a, (c)
		and		#0x40
		jr		z, test5_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test6( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #215
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test6_1:
		in		a, (c)
		and		#0x01
		jr		z, test6_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test6_2:
		in		a, (c)
		and		#0x40
		jr		z, test6_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test7( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #210
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test7_1:
		in		a, (c)
		and		#0x01
		jr		z, test7_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test7_2:
		in		a, (c)
		and		#0x40
		jr		z, test7_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test8( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #210
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test8_1:
		in		a, (c)
		and		#0x01
		jr		z, test8_1
		/* read current system timer */
		in		a, (0xE6)
		ld		b, a
		/* set R#15 */
		ld		a, #2
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		/* wait until VR to non zero */
test8_2:
		in		a, (c)
		and		#0x40
		jr		z, test8_2
		/* read current system timer */
		in		a, (0xE6)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
static void test9( FCB *p_fcb ) {
	int test_time;

	_asm
		di
		ld		c, #0x99
		/* set R#19 */
		ld		a, #128
		out		(c), a
		ld		a, #0x93
		out		(c), a
		/* set R#15 */
		ld		a, #1
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		in		a, (c)
		/* wait until H-SYNC interrupt */
test9_1:
		in		a, (c)
		and		#0x01
		jr		z, test9_1
		/* read current system timer */
		in		a, (0xE7)
		ld		b, a
test9_2:
		in		a, (c)
		and		#0x01
		jr		z, test9_2
		/* read current system timer */
		in		a, (0xE7)
		/* save timer */
		ld		(_end_time), a
		ld		a, b
		ld		(_start_time), a
		/* set R#15 */
		xor		a
		out		(c), a
		ld		a, #0x8F
		out		(c), a
		ei
	_endasm;

	test_time = (int)end_time - (int)start_time;
	if( test_time < 0 ) {
		test_time += 256;
	}
	file_printf( p_fcb, "%d ", test_time );
}

/* --------------------------------------------------------- */
void test10( FCB *p_fcb ) {
	int i;

	_asm
		di
		push	ix
		/* backup interrupt vector */
		ld		hl,#0x0038
		ld		de,#test10_backup
		ld		bc,#3
		ldir
		/* update interrupt vector */
		ld		hl,#test10_new
		ld		de,#0x0038
		ld		bc,#3
		ldir
		/* disable V-SYNC interrupt */
		ld		c,#0x99
		ld		a,#0x40			/* BL=1, IE0=0, SCREEN1 */
		out		(c),a
		ld		a,#0x81
		out		(c),a
		/* enable H-SYNC interrupt */
		ld		a,#0x10			/* IE1=1, SCREEN1 */
		out		(c),a
		ld		a,#0x80
		out		(c),a
		/* loop 1 */
		ld		b,#0
		ld		hl,#_line_data
		ld		ix,#_intr_data
test10_line_loop:
		/* set H-SYNC line */
		ld		a,b
		out		(c),a
		ld		a,#0x80+19
		out		(c),a
		/* clear interrupt flag */
		ld		a,#0x01			/* S#1 */
		out		(c),a
		ld		a,#0x8F
		out		(c),a
		in		a,(c)
		/* R#15 = 0 */
		ld		a,#0x00
		out		(c),a
		ld		a,#0x8F
		out		(c),a
		/* loop 2 */
		ld		c,#0xe7
		in		a,(c)
		and		#32
		ld		d,a
		ei
test10_wait_interrupt0:
		in		a,(c)
		and		#32
		cp		d
		jr		z,test10_wait_interrupt0
test10_wait_interrupt1:
		in		a,(c)
		and		#32
		cp		d
		jr		nz,test10_wait_interrupt1
test10_timeout:
		di
		ld		e,#0
test10_wait_exit:
		ld		0(ix),e
		inc		ix
		/* read S#2 */
		ld		c,#0x99
		ld		a,#2
		out		(c),a
		ld		a,#0x8F
		out		(c),a
		in		a,(c)
		ld		(hl),a
		inc		hl
		inc		b				/* next line */
		jp		nz,test10_line_loop

		/* disable H-SYNC interrupt */
		ld		a,#0x00			/* IE1=0, SCREEN1 */
		out		(c),a
		ld		a,#0x80
		out		(c),a
		/* enable V-SYNC interrupt */
		ld		a,#0x60			/* BL=1, IE0=0, SCREEN1 */
		out		(c),a
		ld		a,#0x81
		out		(c),a
		/* R#15 = 0 */
		xor		a
		out		(c),a
		ld		a,#0x8F
		out		(c),a
		/* restore interrupt vector */
		ld		hl,#test10_backup
		ld		de,#0x0038
		ld		bc,#3
		ldir
		ei
		jp		test10_skip

test10_backup:
		.ds		3
test10_new:
		jp		test10_intr		/* new interrupt vector. 3bytes (0xC3 XX XX) */
test10_intr:
		pop		de				/* clear return address */
		ld		e,#1
		jp		test10_wait_exit
test10_skip:
		pop		ix
	_endasm;

	for( i = 0; i < 256; i++ ) {
		file_printf( p_fcb, "  LINE %03d: [%02X][%02X]\xD\xA", i, (int)line_data[i], (int)intr_data[i] );
		printf( "*" );
	}
	printf( "\n" );
}

/* --------------------------------------------------------- */
static void set_name( FCB *p_fcb, const char *p_name ) {
	int i, j;

	memset( p_fcb, 0, sizeof(FCB) );
	for( i = 0; i < 11; i++ ) {
		p_fcb->name[i] = ' ';
	}
	for( i = 0; (i < 8) && (p_name[i] != 0) && (p_name[i] != '.'); i++ ) {
		p_fcb->name[i] = toupper( p_name[i] );
	}
	if( p_name[i] == '.' ) {
		i++;
		for( j = 0; (j < 3) && (p_name[i + j] != 0) && (p_name[i + j] != '.'); j++ ) {
			p_fcb->ext[j] = toupper( p_name[i + j] );
		}
	}
}

/* --------------------------------------------------------- */
int main( void ) {
	int i;

	memset( &file, 0, sizeof(file) );
	file.drive_no = 0;
	file.current_block = 0;
	set_name( &file, "TEST.TXT" );
	if( fcb_create( &file ) != FCB_SUCCESS ) {
		puts( "Failed: fcb_create()" );
		return 0;
	}

	screen( 1 );
	printf( "192line mode\n" );
	file_printf( &file, "192line mode: " );
	vdp_write( 9, 0x00 );		/* NTSC, non-interlace, 192line */

	printf( "H BLANKING\n" );
	file_printf( &file, "H BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test1( &file );
	}
	printf( "V BLANKING\n" );
	file_printf( &file, "\xD\xAV BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test2( &file );
	}
	printf( "H INTERRUPT TO H BLANKING\n" );
	file_printf( &file, "\xD\xAINTERRUPT TO H BLANKING: " );
	for( i = 0; i < 10; i++ ) {
		test3( &file );
	}
	printf( "INTERRUPT RESPONSE\n" );
	file_printf( &file, "\xD\xAINTERRUPT RESPONSE: " );
	for( i = 0; i < 10; i++ ) {
		test4( &file );
	}
	printf( "LINE220 TO V-BLANK\n" );
	file_printf( &file, "\xD\xALINE220 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test5( &file );
	}
	printf( "LINE215 TO V-BLANK\n" );
	file_printf( &file, "\xD\xALINE215 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test6( &file );
	}
	printf( "LINE220 TO V-BLANK\n" );
	file_printf( &file, "\xD\xALINE210 TO V-BLANK: " );
	for( i = 0; i < 10; i++ ) {
		test7( &file );
	}
	printf( "LINE210 TO V-BLANK(E6)\n" );
	file_printf( &file, "\xD\xALINE210 TO V-BLANK(E6): " );
	for( i = 0; i < 10; i++ ) {
		test8( &file );
	}
	printf( "H INTERRUPT TO H INTERRUPT\n" );
	file_printf( &file, "\xD\xAINTERRUPT TO H INTERRUPT: " );
	for( i = 0; i < 10; i++ ) {
		test9( &file );
	}
	printf( "R#18=0\n" );
	file_printf( &file, "\xD\xAR#18=0\xD\xA" );
	vdp_write( 18, 0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );
	printf( "H-SYNC INTR: (R#23=64)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=64)\xD\xA" );
	vdp_write( 23, 64 );
	test10( &file );
	printf( "H-SYNC INTR: (R#23=128)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=128)\xD\xA" );
	vdp_write( 23, 128 );
	test10( &file );
	printf( "H-SYNC INTR: (R#23=192)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=192)\xD\xA" );
	vdp_write( 23, 192 );
	test10( &file );
	vdp_write( 23, 0 );

	printf( "R#18=0x80\n" );
	file_printf( &file, "\xD\xAR#18=0x80\xD\xA" );
	vdp_write( 18, 0x80 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x90\n" );
	file_printf( &file, "\xD\xAR#18=0x90\xD\xA" );
	vdp_write( 18, 0x90 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xA0\n" );
	file_printf( &file, "\xD\xAR#18=0xA0\xD\xA" );
	vdp_write( 18, 0xA0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xB0\n" );
	file_printf( &file, "\xD\xAR#18=0xB0\xD\xA" );
	vdp_write( 18, 0xB0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xC0\n" );
	file_printf( &file, "\xD\xAR#18=0xC0\xD\xA" );
	vdp_write( 18, 0xC0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xD0\n" );
	file_printf( &file, "\xD\xAR#18=0xD0\xD\xA" );
	vdp_write( 18, 0xD0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xE0\n" );
	file_printf( &file, "\xD\xAR#18=0xE0\xD\xA" );
	vdp_write( 18, 0xE0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0xF0\n" );
	file_printf( &file, "\xD\xAR#18=0xF0\xD\xA" );
	vdp_write( 18, 0xF0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x10\n" );
	file_printf( &file, "\xD\xAR#18=0x10\xD\xA" );
	vdp_write( 18, 0x10 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x20\n" );
	file_printf( &file, "\xD\xAR#18=0x20\xD\xA" );
	vdp_write( 18, 0x20 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x30\n" );
	file_printf( &file, "\xD\xAR#18=0x30\xD\xA" );
	vdp_write( 18, 0x30 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x40\n" );
	file_printf( &file, "\xD\xAR#18=0x40\xD\xA" );
	vdp_write( 18, 0x40 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x50\n" );
	file_printf( &file, "\xD\xAR#18=0x50\xD\xA" );
	vdp_write( 18, 0x50 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x60\n" );
	file_printf( &file, "\xD\xAR#18=0x60\xD\xA" );
	vdp_write( 18, 0x60 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "R#18=0x70\n" );
	file_printf( &file, "\xD\xAR#18=0x70\xD\xA" );
	vdp_write( 18, 0x70 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	printf( "212line mode\n" );
	file_printf( &file, "212line mode: " );
	vdp_write( 9, 0x80 );		/* NTSC, non-interlace, 212line */
	printf( "R#18=0\n" );
	file_printf( &file, "\xD\xAR#18=0\xD\xA" );
	vdp_write( 18, 0 );
	printf( "H-SYNC INTR: (R#23=0)\n" );
	file_printf( &file, "\xD\xAH-SYNC INTR: (R#23=0)\xD\xA" );
	vdp_write( 23, 0 );
	test10( &file );

	vdp_write( 9, 0x00 );		/* NTSC, non-interlace, 192line */

	if( fcb_close( &file ) != FCB_SUCCESS ) {
		puts( "Failed: fcb_close()" );
		return 0;
	}
	printf( "Completed.\n" );
	return 0;
}
